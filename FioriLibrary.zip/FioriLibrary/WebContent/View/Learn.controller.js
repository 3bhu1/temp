sap.ui.controller("com.fl.View.Learn", {

/**
* Called when a controller is instantiated and its View controls (if available) are already created.
* Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
* @memberOf View.Learn
*/
	onInit: function(){
		this.router = sap.ui.core.UIComponent.getRouterFor(this);
		this.router.attachRoutePatternMatched(this._handleRouteMatched, this);
	},
	_handleRouteMatched: function(evt) {
		this.cNum = evt.getParameter("arguments").chapter;
		this.pNum = evt.getParameter("arguments").page;
		this.cNum = this.cNum.substr(7,8);
		this.pNum = this.pNum.substr(4,5);

		var sPath = "/topics/"+(parseInt(this.cNum)-1)+"/pages/"+(parseInt(this.pNum)-1);
		this.getView().bindElement(sPath);
		
		var oHeader = sap.ui.getCore().byId(this.createId("heading"));
		oHeader.bindProperty("text","header");
	
		var oContent = sap.ui.getCore().byId(this.createId("content"));
		oContent.bindProperty("htmlText","content");
		
		var oInput = sap.ui.getCore().byId(this.createId("pNum"));
		oInput.setValue(this.pNum);
		
		if (this.pNum == 1){
			var oPrev = sap.ui.getCore().byId(this.createId("bPrev"));
			oPrev.setEnabled(false);
		}
		else{
			var oPrev = sap.ui.getCore().byId(this.createId("bPrev"));
			oPrev.setEnabled(true);
		}
		
		var oPBar =  sap.ui.getCore().byId(this.createId("processBar"));
		var percent = parseInt(this.pNum)*100/40;
		oPBar.setPercentValue(percent);
		if(percent >= 90){
			oPBar.setState("Success");
			var oNext = sap.ui.getCore().byId(this.createId("bNext"));
			oNext.setEnabled(false);
		}
		else if(percent <= 40){
			oPBar.setState("None");
		}
		else{
			oPBar.setState("Warning");
		}
		
		var context = sap.ui.getCore().byId("splitApp").getModel().getContext('/topics/' + this.topicIndex + '/' +this.pNum);
		this.getView().setBindingContext(context);
	},
/**
* Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
* (NOT before the first rendering! onInit() is used for that one!).
* @memberOf View.Learn
*/
//	onBeforeRendering: function() {
//		
//	}

/**
* Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
* This hook is the same one that SAPUI5 controls get after being rendered.
* @memberOf View.Learn
*/
//	onAfterRendering: function() {
//
//	},

/**
* Called when the Controller is destroyed. Use this one to free resources and finalize activities.
* @memberOf View.Learn
*/
//	onExit: function() {
//
//	}
	onHome:function(evt){
		this.router.navTo("home");
	},
	onPrev:function(evt){
		var context = evt.getSource().getBindingContext().sPath;
		var sViewId = context.substring(context.lastIndexOf("/") + 1);
		sViewId = parseInt(sViewId);
		var cNum = context.substring(8,9);
		cNum = parseInt(cNum)+1;
		this.router.navTo("learn", {
			chapter: "chapter"+cNum,
			page: "page"+sViewId
		});
	},
	onNext:function(evt){
		var context = evt.getSource().getBindingContext().sPath;
		var sViewId = context.substring(context.lastIndexOf("/") + 1);
		sViewId = parseInt(sViewId) + 2;
		var cNum = context.substring(8,9);
		cNum = parseInt(cNum)+1;
		this.router.navTo("learn", {
			chapter: "chapter"+cNum,
			page: "page"+sViewId
		});
	}
});