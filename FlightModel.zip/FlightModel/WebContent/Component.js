jQuery.sap.declare("com.fm.Component");

sap.ui.core.UIComponent.extend("com.fm.Component", {
	metadata: {
		"abstract": true,
		version: "1.0",
		routing: {
			config: {
				viewType: "XML",
				viewPath: "com.fm.view",
				clearTarget: false,
				transition: "slide"
			},
			routes: [{
					pattern: "",
					name: "default",
					view: "Menu",
					targetControl: "fioriContent",
					targetAggregation: "masterPages",
					subroutes: [{
						pattern: "",
						name: "searchFlights",
						view: "SearchFlights",
						targetAggregation: "detailPages"
					}
				]
				}
			]

		}
	},
	init: function() {
		jQuery.sap.require("sap.m.routing.RouteMatchedHandler");
		jQuery.sap.require("sap.ui.core.routing.HashChanger");
//
//		//call createContent
		sap.ui.core.UIComponent.prototype.init.apply(this, arguments);
//
		this._router = this.getRouter();
//
		//initlialize the router
		this._routeHandler = new sap.m.routing.RouteMatchedHandler(this._router);
		this._router.initialize();

	},
	createContent: function() {
		var oView = sap.ui.view({
			id: "mainView",
			viewName: "com.fm.view.Main",
			type: "XML",
			viewData: {
				component: this
			}
		});
		var i18nModel = new sap.ui.model.resource.ResourceModel({
			bundleUrl:"i18n/i18n.properties"
		});
		oView.setModel(i18nModel,"i18n");
//		var oModel = new sap.ui.model.json.JSONModel('model/Topics.json');
//		oView.setModel(oModel);
		
		return oView;
	}
})