jQuery.sap.declare("com.fl.util.Formatter");
com.fl.util.Formatter = {
		CompletePercent: function(value){
			if (value == 100)
			{
				return("Completed");
			}
			else if(value == 0)
			{
				return("Not Sarted");
			}
			else {
				return(value + "% Completed");
			}			
		},
		state:function(value){
			if(value == 100)
				{
				return ("Success");
				}
			else if(value == 0)
				{
				return ("Error");
				}
			else{
				return ("Warning");
			}
		},
		type:function(value){
			if(value!="Locked")
				return("Active");
		}
};